<?php
$link=mysqli_connect("localhost","root","","shopdb");
//$link=mysqli_connect("localhost","h314287_schoolshopDB","Z8bFzTjR","h314287_MahdiDB");

?>

